# GoldWatch_WWW
This is repo contains the web front end components. This is used by CodeDeploy to deploy into EC2 Instances running in GoldWatch. 
# GoldWatch_WWW
# GoldWatch_WWW
